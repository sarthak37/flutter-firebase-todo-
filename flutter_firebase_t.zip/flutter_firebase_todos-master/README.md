# Flutter Firebase todo

This app is an example of how to use Firebase in Flutter application.

## Getting Started

1. made by sarthak
2. Create a Firebase application and download google-services.json file and put it in android/app folder.
3. From the terminal in the project folder run :
    ```
    flutter pub get
    ```
4. run the app from the terminal run :
    ```
    flutter run
    ```
